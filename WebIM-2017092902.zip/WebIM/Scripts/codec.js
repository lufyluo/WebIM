function CodecProcessor (params) {
}

CodecProcessor.prototype.set = function (name, value) {  
}

/**
  * Temporary buffers
  */
CodecProcessor.prototype.buffer = null;

/**
  * Input buffers
  */
CodecProcessor.prototype.input = null;

/**
  * Encoded/Decoded audio frames
  */
CodecProcessor.prototype.output = null;

/**
  * Internal state
  */
CodecProcessor.prototype.state = null;