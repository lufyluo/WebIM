﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebIM.Models.WebIM
{
    public class Index
    {
        public string userid { get; set; }
        public string username { get; set; }
    }
}