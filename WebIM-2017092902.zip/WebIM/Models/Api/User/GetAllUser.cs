﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebIM.Models.Api.User
{
    public class GetAllUser:Login
    {
       
    }
}